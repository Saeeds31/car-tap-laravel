<?php

namespace Modules\CarRequest\Database\Seeders;

use Illuminate\Database\Seeder;

class CarRequestDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
