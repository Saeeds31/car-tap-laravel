<x-carrequest::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('carrequest.name') !!}</p>
</x-carrequest::layouts.master>
