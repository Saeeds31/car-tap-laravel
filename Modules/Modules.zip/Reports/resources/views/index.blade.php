<x-reports::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('reports.name') !!}</p>
</x-reports::layouts.master>
