<?php

use Illuminate\Support\Facades\Route;
use Modules\Contract\Http\Controllers\BusinessController;
use Modules\Contract\Http\Controllers\ContractController;

Route::middleware(['auth:sanctum'])->prefix('v1/admin')->group(function () {
    Route::apiResource('business', BusinessController::class)->names('business');
    Route::get('contracts', [ContractController::class, 'index'])->name('contract-index');
    Route::get('contracts/{id}', [ContractController::class, 'show'])->name('contract-show');
    Route::post('contracts/change-status/{id}', [ContractController::class, 'changeStatus'])->name('contract-changeStatus');
    Route::post('contracts/add-users/{id}', [ContractController::class, 'addUserToContract'])->name('contract-addUserToContract');
    Route::post('contracts/edit/{id}', [ContractController::class, 'changeContract'])->name('contract-changeContract');
});

Route::prefix('v1/front')->group(function () {
    Route::get('business', [BusinessController::class, 'index'])->name('business');
    Route::post('employer-otp', [ContractController::class, 'sendMessage'])->name('send-otp-employer');
    Route::post('contract', [ContractController::class, 'preContractFromEmployer'])->name('preContractFromEmployer');
});
