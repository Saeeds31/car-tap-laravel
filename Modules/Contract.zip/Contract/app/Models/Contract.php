<?php

namespace Modules\Contract\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Employers\Models\Employers;
use Modules\Locations\Models\City;
use Modules\Locations\Models\Province;
use Modules\Users\Models\User;

// use Modules\Contract\Database\Factories\ContractFactory;

class Contract extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'employer_id',
        'agent_id',
        'business_id',
        'from_date',
        'to_date',
        'address',
        'number_people',
        'amount',
        'extra_amount',
        'employer_description',
        'description',
        'business_label',
        'city_id',
        'province_id',
        'status'
    ];
    protected $table = "contracts";
    public function agent()
    {
        return $this->belongsTo(User::class);
    }
    public function employer()
    {
        return $this->belongsTo(Employers::class);
    }
    public function business()
    {
        return $this->belongsTo(Business::class);
    }
    public function city()
    {
        return $this->belongsTo(City::class);
    }
    public function province()
    {
        return $this->belongsTo(Province::class);
    }

    public function users()
    {
        return $this->belongsToMany(User::class, 'contracts_users', 'contract_id', 'user_id');
    }
}
