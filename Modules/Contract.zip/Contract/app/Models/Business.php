<?php

namespace Modules\Contract\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Modules\Contract\Database\Factories\BusinessFactory;

class Business extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = ['title'];
    protected $table = "business";

    public function contracts()
    {
        return $this->hasMany(Contract::class);
    }
}
