<?php

namespace Modules\Contract\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Contract\Models\Business;
use Modules\Notifications\Services\NotificationService;

class BusinessController extends Controller
{

    public function index()
    {

        $business = Business::orderBy('id')->latest('id')->get();
        return response()->json([
            'success' => true,
            'message' => 'لیست نوع کسب و کارها',
            'data'    => $business
        ]);
    }

    /**
     * Store a newly created city in storage.
     */
    public function store(Request $request, NotificationService $notifications)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
        ]);

        $business = Business::create($data);

        $notifications->create(
            "ثبت نوع کسب و کار",
            "نوع کسب و کار {$business->title}  در سیستم ثبت شد",
            "notification_content",
            ['business' => $business->id]
        );
        return response()->json([
            'success' => true,
            'message' => 'نوع کسب و کار با موفقیت ذخیره شد',
            'data'    => $business
        ], 201);
    }

    /**
     * Display the specified city.
     */
    public function show(Business $business)
    {
        return response()->json([
            'success' => true,
            'message' => 'جزئیات یک نوع کسب و کار',
            'data'    => $business
        ]);
    }

    /**
     * Update the specified city in storage.
     */
    public function update(Request $request, Business $business, NotificationService $notifications)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
        ]);

        $business->update($data);

        $notifications->create(
            "ویرایش نوع کسب و کار",
            "نوع کسب و کار {$business->title}  در سیستم ویرایش شد",
            "notification_content",
            ['bus$business' => $business->id]
        );
        return response()->json([
            'success' => true,
            'message' => 'نوع کسب و کار با موفقیت ویرایش شد',
            'data'    => $business
        ]);
    }

    /**
     * Remove the specified city from storage.
     */
    public function destroy(Business $business, NotificationService $notifications)
    {

        $notifications->create(
            "حذف نوع کسب و کار",
            "نوع کسب و کار {$business->name}  از سیستم حذف شد",
            "notification_content",
            ['business' => $business->id]
        );
        $business->delete();

        return response()->json([
            'success' => true,
            'message' => 'نوع کسب و کار با موفقیت حذف شد'
        ]);
    }
}
