<?php

namespace Modules\Contract\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Services\SmsService;
use GrahamCampbell\ResultType\Success;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Modules\Contract\Models\Contract;
use Modules\Employers\Models\Employers;
use Modules\Notifications\Services\NotificationService;
use Modules\Users\Models\Otp;

class ContractController extends Controller
{
    public function sendOtp($mobile)
    {
        $mobile = trim($mobile);
        $token = rand(100000, 999999);
        Otp::updateOrCreate(
            ['mobile' => $mobile],
            ['token' => $token, 'expires_at' => now()->addMinutes(5)]
        );
        $response = Http::get("https://api.kavenegar.com/v1/71705A6858737476417466345933356B3578614C44396154756F6B384833424A3646674B4F4F585577764D3D/verify/lookup.json", [
            'receptor' => $mobile,
            'token'    => $token,
            'template' => "verifycode"
        ]);
        Log::info('Kavenegar response: ' . $response->body());
        return true;
    }
    public function sendMessage(Request $request)
    {
        $request->validate([
            'mobile' => [
                'required',
                'regex:/^09\d{9}$/'
            ],
        ], [
            'mobile.required' => 'شماره موبایل الزامی است.',
            'mobile.regex' => 'شماره موبایل معتبر نیست. شماره باید با 09 شروع شده و 11 رقم باشد.',
        ]);
        $this->sendOtp($request->mobile);
        return response()->json(['message' => 'کد یکبار مصرف با موفقیت ارسال شد', 'success' => true]);
    }
    public function index(Request $request)
    {
        $query = Contract::with(['employer', 'business', 'city', 'province', 'agent', 'users'])->latest('id');
        $admin = $request->user();

        $adminPermissions = is_array($admin->permissions ?? null) ? $admin->permissions : [];
        $cityPermissions = array_filter($adminPermissions, function ($permission) {
            return str_starts_with($permission, 'citymanager_');
        });
        $cityIds = array_map(function ($perm) {
            return intval(str_replace('citymanager_', '', $perm));
        }, $cityPermissions);
        if (!empty($cityIds)) {
            $query->whereIn('city_id', $cityIds);
        } else {

            if ($province_id = $request->get('province_id')) {
                $query->where('province_id', $province_id);
            }
        }
        if ($fullName = $request->get('full_name')) {
            $query->whereHas('employer', function ($q) use ($fullName) {
                $q->where('full_name', 'like', "%{$fullName}%");
            });
        }
        if ($mobile = $request->get('mobile')) {
            $query->whereHas('employer', function ($q) use ($mobile) {
                $q->where('mobile', 'like', "%{$mobile}%");
            });
        }
        if ($national_code = $request->get('national_code')) {
            $query->whereHas('employer', function ($q) use ($national_code) {
                $q->where('national_code', 'like', "%{$national_code}%");
            });
        }
        if ($business_id = $request->get('business_id')) {
            $query->where('business_id', $business_id);
        }
        if ($status = $request->get('status')) {
            $query->where('status', $status);
        }
        if ($amount = $request->get('amount')) {
            $query->where('amount', '>=', $amount);
        }
        return response()->json($query->paginate(20));
    }
    public function preContractFromEmployer(Request $request, NotificationService $notifications)
    {

        $data = $request->validate([
            'address' => 'required|string|min:10',
            'employer_description' => 'nullable|string|min:5',
            'full_name' => 'required|string|min:5',
            'token'  => 'required|digits:6',
            'mobile' => [
                'required',
                'regex:/^09\d{9}$/'
            ],
            'national_code' => 'nullable|string|size:10',
            'from_date'    => ['required', 'date'],
            'to_date'    => ['required', 'date'],
            'number_people' => 'required|integer|min:1',
            'business_id' => 'required|integer|exists:business,id',
            'business_label' => 'required|string|min:2',
            'city_id' => 'required|integer|exists:cities,id',
            'province_id' => 'required|integer|exists:provinces,id',
        ]);
        $national_code = trim($data['national_code']);
        $full_name = trim($data['full_name']);
        $mobile = trim($data['mobile']);

        // 1) اعتبارسنجی OTP
        $otp = Otp::where('mobile', $mobile)
            ->where('token', $data['token'])
            ->where('expires_at', '>', now())
            ->first();

        if (!$otp) {
            return response()->json([
                'message' => 'کد اعتبار خود را از دست داده است. مجدد تلاش کنید',
                'success' => false
            ], 422);
        }
        $employer = Employers::where('mobile', $data['mobile'])->first();
        if ($employer) {
            $existSameContract = Contract::where('employer_id', $employer->id)->where('business_label', $data['business_label'])->where('from_date', $data['from_date'])->where('to_date', $data['to_date'])->first();
            if ($existSameContract) {
                return response()->json([
                    'message' => "شما یک درخواست مشابه برای این قرارداد از قبل ثبت کرده اید",
                    'success' => "false",
                ], 403);
            }
        } else {
            $employer =  Employers::create([
                'full_name' => $full_name,
                'mobile' => $data['mobile'],
                'national_code' => $national_code
            ]);
        }
        $contract = Contract::create(
            [
                'employer_id' => $employer->id,
                'agent_id' => null,
                'business_id' => $data["business_id"],
                'from_date' => $data["from_date"],
                'to_date' => $data["to_date"],
                'address' => $data["address"],
                'status' => 'pending',
                'number_people' => $data["number_people"],
                'description' => "",
                'business_label' => $data["business_label"],
                'city_id' => $data["city_id"],
                'province_id' => $data["province_id"],
            ]
        );
        // 5) ثبت نوتیفیکیشن
        $notifications->create(
            "ثبت قرارداد از سمت کارفرما",
            "یک قرار داد از سمت کارفرما در سیستم ثبت شد",
            "notification_contract",
            ['contract' => $contract->id]
        );

        return response()->json([
            'message' => 'اطلاعات شما با موفقیت ثبت شد',
            'success' => true,
        ]);
    }
    public function changeStatus(Request $request, $id)
    {
        $validated = $request->validate([
            'status' => 'required|in:rejected,accepted,doing,done',
            'description' => 'nullable|string',
        ]);

        $admin = $request->user();

        $adminPermissions = is_array($admin->permissions ?? null) ? $admin->permissions : [];
        $cityPermissions = array_filter(
            $adminPermissions,
            fn($permission) =>
            str_starts_with($permission, 'citymanager_')
        );

        $cityIds = array_map(
            fn($perm) =>
            intval(str_replace('citymanager_', '', $perm)),
            $cityPermissions
        );

        $contract = Contract::with(['employer', 'business', 'city', 'province'])
            ->findOrFail($id);


        if (!empty($cityIds) && !in_array($contract->city_id, $cityIds)) {
            return response()->json([
                'message' => "شما اجازه ویرایش این قرارداد را ندارید",
                'success' => false,
            ], 403);
        }
        if ($contract->agent_id) {
            if ($contract->agent_id != $admin->id) {
                return response()->json([
                    'message' => "نماینده این قرارداد شخص دیگری است و شما اجازه ویرایش این قرارداد را ندارید",
                    'success' => false,
                ], 403);
            }
        } else {
            $contract->agent_id = $admin->id;
        }
        $contract->status = $validated['status'];
        $contract->save();
        $employer = $contract->employer;
        if ($validated['status'] == 'rejected') {
            $sms = new SmsService();
            $sms->sendText($employer->mobile, "قرارداد شما به علت زیر رد شد\n{$validated['description']}\n تکین آرتا پرگاس");
        } else if ($validated['status'] == 'accepted') {
            $sms = new SmsService();
            $sms->sendText($employer->mobile, "قرارداد شما با موفقیت تایید شد و به زودی با شما ارتباط حاصل خواهد شد\n تکین آرتا پرگاس");
        }
        return response()->json([
            'message' => "وضعیت با موفقیت ویرایش شد",
            'success' => true,
            'data'    => $contract
        ]);
    }

    public function show(Request $request, $id)
    {

        $admin = $request->user();
        $adminPermissions = is_array($admin->permissions ?? null) ? $admin->permissions : [];
        $cityPermissions = array_filter(
            $adminPermissions,
            fn($permission) =>
            str_starts_with($permission, 'citymanager_')
        );

        $cityIds = array_map(
            fn($perm) =>
            intval(str_replace('citymanager_', '', $perm)),
            $cityPermissions
        );

        $contract = Contract::with(['employer', 'business', 'city', 'province', 'users.city', 'agent'])
            ->findOrFail($id);

        if (!empty($cityIds) && !in_array($contract->city_id, $cityIds)) {
            return response()->json([
                'message' => "شما اجازه دسترسی به قرارداد را ندارید",
                'success' => false,
            ], 403);
        }
        return response()->json([
            'message' => "جزئیات قرارداد",
            'success' => true,
            'data'    => $contract
        ]);
    }
    public function changeContract(Request $request, $id)
    {
        $validated = $request->validate([
            'amount' => 'required|integer|min:1000',
            'extra_amount' => 'nullable|integer|min:1000',
            'description' => 'nullable|string|min:100'
        ]);

        $admin = $request->user();

        $adminPermissions = is_array($admin->permissions ?? null) ? $admin->permissions : [];
        $cityPermissions = array_filter(
            $adminPermissions,
            fn($permission) =>
            str_starts_with($permission, 'citymanager_')
        );

        $cityIds = array_map(
            fn($perm) =>
            intval(str_replace('citymanager_', '', $perm)),
            $cityPermissions
        );

        $contract = Contract::with(['employer', 'business', 'city', 'province'])
            ->findOrFail($id);

        if (!empty($cityIds) && !in_array($contract->city_id, $cityIds)) {
            return response()->json([
                'message' => "شما اجازه ویرایش این قرارداد را ندارید",
                'success' => false,
            ], 403);
        }
        if ($contract->status === 'done') {
            return response()->json([
                'message' => "امکان ویرایش قرارداد انجام شده وجود ندارد",
                'success' => false,
            ], 403);
        }
        if ($contract->agent_id) {
            if ($contract->agent_id != $admin->id) {
                return response()->json([
                    'message' => "نماینده این قرارداد شخص دیگری است و شما اجازه ویرایش این قرارداد را ندارید",
                    'success' => false,
                ], 403);
            }
        } else {
            $contract->agent_id = $admin->id;
        }
        $contract->amount = $validated['amount'];
        $contract->extra_amount = $validated['extra_amount'];
        $contract->description = $validated['description'];
        $contract->save();
        return response()->json([
            'message' => "قرارداد با موفقیت ویرایش شد",
            'success' => true,
            'data'    => $contract
        ]);
    }

    public function addUserToContract(Request $request, $id)
    {
        $validated = $request->validate([
            'user_ids' => ['required', 'array'],
            'user_ids.*' => ['exists:users,id'],
        ]);

        $admin = $request->user();

        $adminPermissions = is_array($admin->permissions ?? null) ? $admin->permissions : [];
        $cityPermissions = array_filter(
            $adminPermissions,
            fn($permission) =>
            str_starts_with($permission, 'citymanager_')
        );

        $cityIds = array_map(
            fn($perm) =>
            intval(str_replace('citymanager_', '', $perm)),
            $cityPermissions
        );

        $contract = Contract::with(['employer', 'business', 'city', 'province', 'users'])
            ->findOrFail($id);

        if (!empty($cityIds) && !in_array($contract->city_id, $cityIds)) {
            return response()->json([
                'message' => "شما اجازه دسترسی به این قرارداد را ندارید",
                'success' => false,
            ], 403);
        }
        if ($contract->status === 'done') {
            return response()->json([
                'message' => "امکان ویرایش قرارداد انجام شده وجود ندارد",
                'success' => false,
            ], 403);
        }
        if ($contract->agent_id) {
            if ($contract->agent_id != $admin->id) {
                return response()->json([
                    'message' => "نماینده این قرارداد شخص دیگری است و شما اجازه ویرایش این قرارداد را ندارید",
                    'success' => false,
                ], 403);
            }
        } else {
            $contract->agent_id = $admin->id;
        }
        if (!empty($validated['user_ids'])) {
            $contract->users()->sync($validated['user_ids']);
        }
        return response()->json([
            'message' => "نفرات با موفقیت به قرارداد اضافه شدند",
            'success' => true,
            'data'    => $contract->load('users')
        ]);
    }
}
