<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('contracts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('employer_id')->nullable()->constrained('employers')->onDelete('cascade');
            $table->foreignId('business_id')->nullable()->constrained('business')->onDelete('cascade');
            $table->date('from_date');
            $table->date('to_date');
            $table->text('address');
            $table->string('business_label');
            $table->integer('number_people');
            $table->integer('amount')->nullable();
            $table->integer('extra_amount')->nullable();
            $table->text('employer_description')->nullable();
            $table->text('description')->nullable();
            $table->enum('status', ['pending', 'rejected', 'accepted','doing', 'done'])->default('pending');
            $table->foreignId('city_id')->nullable()->constrained('cities')->onDelete('cascade');
            $table->foreignId('province_id')->nullable()->constrained('provinces')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('contracts');
    }
};
