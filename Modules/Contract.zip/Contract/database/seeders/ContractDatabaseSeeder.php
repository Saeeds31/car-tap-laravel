<?php

namespace Modules\Contract\Database\Seeders;

use Illuminate\Database\Seeder;

class ContractDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
