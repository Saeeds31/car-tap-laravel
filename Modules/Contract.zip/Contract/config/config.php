<?php

return [
    'name' => 'Contract',
];
