<x-contract::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('contract.name') !!}</p>
</x-contract::layouts.master>
