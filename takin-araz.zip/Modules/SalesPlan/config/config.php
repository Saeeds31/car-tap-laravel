<?php

return [
    'name' => 'SalesPlan',
];
