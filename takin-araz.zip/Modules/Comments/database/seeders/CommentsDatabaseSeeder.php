<?php

namespace Modules\Comments\Database\Seeders;

use Illuminate\Database\Seeder;

class CommentsDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
