<x-comments::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('comments.name') !!}</p>
</x-comments::layouts.master>
