<?php

namespace Modules\ArticleCategories\Database\Seeders;

use Illuminate\Database\Seeder;

class ArticleCategoriesDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
