<x-articlecategories::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('articlecategories.name') !!}</p>
</x-articlecategories::layouts.master>
