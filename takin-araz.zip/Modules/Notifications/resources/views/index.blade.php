<x-notifications::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('notifications.name') !!}</p>
</x-notifications::layouts.master>
