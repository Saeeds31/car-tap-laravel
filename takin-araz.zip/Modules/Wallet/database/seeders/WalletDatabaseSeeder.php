<?php

namespace Modules\Wallet\Database\Seeders;

use Illuminate\Database\Seeder;

class WalletDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
