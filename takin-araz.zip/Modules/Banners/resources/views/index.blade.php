<x-banners::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('banners.name') !!}</p>
</x-banners::layouts.master>
