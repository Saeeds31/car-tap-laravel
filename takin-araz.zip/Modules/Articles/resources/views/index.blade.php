<x-articles::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('articles.name') !!}</p>
</x-articles::layouts.master>
