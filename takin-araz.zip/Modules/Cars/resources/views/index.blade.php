<x-cars::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('cars.name') !!}</p>
</x-cars::layouts.master>
