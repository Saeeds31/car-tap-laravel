<x-startproject::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('startproject.name') !!}</p>
</x-startproject::layouts.master>
