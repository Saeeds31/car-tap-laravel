<?php

return [
    'name' => 'Sliders',
];
