<?php

namespace Modules\Specifications\Database\Seeders;

use Illuminate\Database\Seeder;

class SpecificationsDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
