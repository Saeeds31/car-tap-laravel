<x-specifications::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('specifications.name') !!}</p>
</x-specifications::layouts.master>
