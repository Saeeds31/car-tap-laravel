<x-settings::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('settings.name') !!}</p>
</x-settings::layouts.master>
