<x-team::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('team.name') !!}</p>
</x-team::layouts.master>
