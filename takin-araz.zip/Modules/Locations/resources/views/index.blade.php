<x-locations::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('locations.name') !!}</p>
</x-locations::layouts.master>
