<x-sendsms::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('sendsms.name') !!}</p>
</x-sendsms::layouts.master>
