<?php

namespace Modules\SendSms\Database\Seeders;

use Illuminate\Database\Seeder;

class SendSmsDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
