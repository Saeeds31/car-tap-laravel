<x-receipt::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('receipt.name') !!}</p>
</x-receipt::layouts.master>
