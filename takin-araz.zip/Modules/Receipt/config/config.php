<?php

return [
    'name' => 'Receipt',
];
