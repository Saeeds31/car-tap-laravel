<?php

namespace Modules\Receipt\Database\Seeders;

use Illuminate\Database\Seeder;

class ReceiptDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
